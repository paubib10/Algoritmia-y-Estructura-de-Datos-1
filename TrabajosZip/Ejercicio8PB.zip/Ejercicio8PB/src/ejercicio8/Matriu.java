package ejercicio8;

/**
 * Esta clase representa una matriz con operaciones básicas como adición y
 * multiplicación. Para esto utiliza un array Row-major order
 *
 * @author Pau Toni Bibiloni Martínez &amp; Blanca Atienzar Martínez
 */
public class Matriu {

    private int columna, fila;
    private int x, y;
    private Integer[][] matriu;

    /**
     * Constructor para crear una matriz con el número de filas y columnas
     * especificado.
     *
     * @param fila El número de filas.
     * @param columna El número de columnas. O(1), es constante
     */
    public Matriu(int fila, int columna) {
        this.columna = columna;
        this.fila = fila;
        matriu = new Integer[fila][columna];
        this.x = 0;
        this.y = 0;
    }

    /**
     * Agrega un elemento a la matriz. Si la matriz está llena, muestra un
     * mensaje de error.
     *
     * @param elemento El elemento a agregar a la matriz. O(n)
     */
    public void add(int elemento) {
        if (esPlena()) {
            throw new IllegalArgumentException("Las matriu esta plena");
        } else {
            if (x < fila && y >= columna) {
                y = 0;
                x++;
            }
            matriu[x][y] = elemento;
            //System.out.println("matriu[" + x + "][" + y + "]= " + matriu[x][y] + " ");
            y++;
        }
    }

    /**
     * Realiza la multiplicación de dos matrices y devuelve el resultado en una
     * nueva matriz.
     *
     * @param matriuDos La segunda matriz a multiplicar.
     * @return La matriz resultante de la multiplicación o una vacía en caso de
     * error. O(n^3)
     */
    public Matriu multiplicar(Matriu matriuDos) {
        if (!esPlena() || !matriuDos.esPlena()) {
            throw new IllegalArgumentException("Les matrius no estan plenas");
        }if (columna != matriuDos.getFilas()) {
            throw new IllegalArgumentException("Las matrices no son compatibles para la multiplicación");
        }
         else {
            int resultado = 0;
            int multiplicaciones = 0;
            Matriu new_matriu = new Matriu(fila, matriuDos.getColumnas());
            for (int i = 0; i < fila; i++) {
                for (int j = 0; j < matriuDos.getColumnas(); j++) {
                    for (int k = 0; k < columna; k++) {
                        resultado += matriu[i][k] * matriuDos.getElement(k, j);
                        multiplicaciones++;
                    }
                    new_matriu.add(resultado);
                    resultado = 0;
                }
            }
            System.out.println("Número de multiplicaciones: " + multiplicaciones);
            return new_matriu;
        }
    }

    /**
     * Obtiene el número de filas en la matriz.
     *
     * @return El número de filas. O(1), es constante
     */
    public int getFilas() {
        return fila;
    }

    /**
     * Obtiene el número de columnas en la matriz.
     *
     * @return El número de columnas. O(1), es constante
     */
    public int getColumnas() {
        return columna;
    }

    /**
     * Obtiene un elemento específico en la matriz en la posición dada.
     *
     * @param f La fila del elemento.
     * @param c La columna del elemento.
     * @return El elemento en la posición (f, c). O(1), es constante
     */
    public int getElement(int f, int c) {
        return matriu[f][c];
    }

    /**
     * Verifica si la matriz está llena.
     *
     * @return true si la matriz está llena, false en caso contrario. O(1), es
     * constante
     */
    public boolean esPlena() {
        return (matriu[fila - 1][columna - 1] != null);
    }

}

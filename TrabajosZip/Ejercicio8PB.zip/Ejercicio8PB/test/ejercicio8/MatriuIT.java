package ejercicio8;

import org.junit.Test;

import ejercicio8.Matriu;
import static org.junit.Assert.assertEquals;

/**
 *
 * @author Pau Toni Bibiloni Martínez &amp; Blanca Atienzar Martínez
 */
public class MatriuIT {
    
    @Test
    public void testMultiplicarMatrices() {
        // Crear instancias de Matriz
        Matriu matriuUno = new Matriu(2, 3);
        matriuUno.add(10); matriuUno.add(20); matriuUno.add(30);
        matriuUno.add(40); matriuUno.add(50); matriuUno.add(60);
       
        
        Matriu matriuDos = new Matriu(3, 2);
        matriuDos.add(11); matriuDos.add(12); 
        matriuDos.add(13); matriuDos.add(14);
        matriuDos.add(15); matriuDos.add(16);

        // Realizar la multiplicación
        Matriu resultado = matriuUno.multiplicar(matriuDos);
        
        // Resultado esperado de la multiplicación
        Matriu resultadoEsperado = new Matriu(2, 2);
        resultadoEsperado.add(820); resultadoEsperado.add(880); 
        resultadoEsperado.add(1990); resultadoEsperado.add(2140);

        // Verificar que el resultado sea el esperado
        assertEquals(resultadoEsperado.getElement(0, 0),resultado.getElement(0, 0));
        assertEquals(resultadoEsperado.getElement(0, 1),resultado.getElement(0, 1));
        assertEquals(resultadoEsperado.getElement(1, 0),resultado.getElement(1, 0));
        assertEquals(resultadoEsperado.getElement(1, 1),resultado.getElement(1, 1));
    }

    @Test
    public void testMatricesIncompatibles() {
   
        // Crear instancias de Matriz
        Matriu matriuUno = new Matriu(3, 3);
        matriuUno.add(10); matriuUno.add(20); matriuUno.add(30);
        matriuUno.add(40); matriuUno.add(50); matriuUno.add(60);
        matriuUno.add(70); matriuUno.add(80); matriuUno.add(90);
        
        Matriu matriuDos = new Matriu(2, 3);
        matriuDos.add(11); matriuDos.add(12); 
        matriuDos.add(13); matriuDos.add(14);
        matriuDos.add(15); matriuDos.add(16); 

        try {
            // Intentar multiplicar matrices incompatibles
            matriuUno.multiplicar(matriuDos);
            
        } catch (IllegalArgumentException e) {
            // La excepción es esperada, la prueba es exitosa
            assertEquals("Las matrices no son compatibles para la multiplicación", e.getMessage());
        }
    }
    
    public void testMatricesNoLlenas() {
   
        // Crear instancias de Matriz
        Matriu matriuUno = new Matriu(3, 3);
        matriuUno.add(10); matriuUno.add(20); matriuUno.add(30);
        matriuUno.add(40); matriuUno.add(50); matriuUno.add(60);
        matriuUno.add(70); matriuUno.add(80); 
        
        Matriu matriuDos = new Matriu(2, 3);
        matriuDos.add(11); matriuDos.add(12); 
        matriuDos.add(13); matriuDos.add(14);
        matriuDos.add(15); matriuDos.add(16); 

        try {
            // Intentar multiplicar matrices incompatibles
            matriuUno.multiplicar(matriuDos);
            
        } catch (IllegalArgumentException e) {
            // La excepción es esperada, la prueba es exitosa
            assertEquals("Les matrius no estan plenas", e.getMessage());
        }
    }
    
    public void testMatricesEstaLlenas() {
   
        // Crear instancias de Matriz
        Matriu matriuUno = new Matriu(3, 3);
        matriuUno.add(10); matriuUno.add(20); matriuUno.add(30);
        matriuUno.add(40); matriuUno.add(50); matriuUno.add(60);
        matriuUno.add(70); matriuUno.add(80); matriuUno.add(11); 
        
        
        try {
            // Intentar mas elementos de los que caben
            matriuUno.add(12); 
            
        } catch (IllegalArgumentException e) {
            // La excepción es esperada, la prueba es exitosa
            assertEquals("Las matriu esta plena", e.getMessage());
        }
    }

   
    
}
